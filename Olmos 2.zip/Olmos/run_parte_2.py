#!/usr/bin/env python3
"""Lanzador de conveniencia para ejecutar la Parte 2 (Gráficas Computacionales 3D)."""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARTE_2_DIR = os.path.join(BASE_DIR, "Parte_2_Graficas_Computacionales")

if __name__ == "__main__":
    os.chdir(PARTE_2_DIR)
    sys.path.insert(0, PARTE_2_DIR)
    # Ejecutar main de la Parte 2
    os.system(f'"{sys.executable}" "{os.path.join(PARTE_2_DIR, "main.py")}"')

