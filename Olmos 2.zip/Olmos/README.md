# TC2008B - Actividad Integradora: Sistemas Multiagentes con Gráficas Computacionales

**Materia:** TC2008B - Modelación de Sistemas Multiagentes con Gráficas Computacionales  
**Evidencia 1 (Semana 12)** - Tecnológico de Monterrey  

---

## 🗂️ Estructura del Repositorio

El proyecto se encuentra estrictamente dividido en dos carpetas independientes según los requerimientos de la entrega:

```text
Olmos/
├── run_parte_1.py                          # Lanzador principal de la Parte 1
├── run_parte_2.py                          # Lanzador principal de la Parte 2
├── entorno/                                # Entorno virtual Python con pygame
├── Parte_1_Sistemas_Multiagentes/          # [PARTE 1] Simulación Multiagente (Semana 12)
│   ├── agente_robot.py                     # Agente Robot (4 sensores, presión, BFS, FSM)
│   ├── modelo_almacen.py                   # Modelo espacial MxN, telemetría y estigmergia
│   ├── simulacion_visual.py                # Visualización 2D interactiva con HUD (Pygame)
│   ├── simulacion_consola.py               # Ejecución en consola con animación ASCII
│   ├── experimentos.py                     # Batería Monte Carlo (Subcompetencia SICT0102)
│   ├── main.py                             # CLI con soporte de flags
│   ├── DOCUMENTO_ENTREGA_PARTE_1.md        # Documento técnico formal de entrega (Destacado)
│   ├── DOCUMENTO_ENTREGA_PARTE_1.html      # Versión imprimible para generar PDF
│   └── README.md                           # Documentación técnica de la Parte 1
└── Parte_2_Graficas_Computacionales/        # [PARTE 2] Gráficas Computacionales 3D desde cero
    ├── escena_3d.py                        # Pipeline gráfico 3D matemático (Bresenham)
    ├── almacen_3d.py                       # Geometría procedimental (estantes, piso, almacén)
    ├── agente_robot.py                     # Robots 3D, ruedas Mecanum y sirenas de luz
    ├── matriz3d.py                         # Álgebra lineal 3D (OpMat3D, matrices 4x4)
    ├── main.py                             # Punto de entrada de la Parte 2
    └── README.md                           # Documentación de la Parte 2
```

---

## 🚀 Instrucciones de Ejecución

### Parte 1: Sistemas Multiagentes (Simulación del Almacén)

Para ejecutar la simulación visual 2D interactiva:
```bash
python run_parte_1.py
```
*Controles en ventana:*
- <kbd>ESPACIO</kbd>: Pausar / Reanudar.
- <kbd>E</kbd>: Alternar en vivo entre estrategia **BASE** y **OPTIMIZADA**.
- <kbd>R</kbd>: Reiniciar simulación.
- <kbd>↑</kbd> / <kbd>↓</kbd>: Ajustar velocidad de simulación.

Para ejecutar la batería de experimentos científicos Monte Carlo (Subcompetencia **SICT0102**):
```bash
python run_parte_1.py --experimentos
```

Para generar o exportar el reporte a PDF:
- Abre `Parte_1_Sistemas_Multiagentes/DOCUMENTO_ENTREGA_PARTE_1.html` en tu navegador y haz clic en **"🖨️ Guardar como PDF / Imprimir"**.

---

### Parte 2: Gráficas Computacionales 3D

Para ejecutar la simulación gráfica 3D implementada enteramente desde cero con álgebra matricial y rasterizado en Python:
```bash
python run_parte_2.py
```
*Controles 3D:*
- <kbd>W</kbd>, <kbd>A</kbd>, <kbd>S</kbd>, <kbd>D</kbd>: Mover cámara en primera/tercera persona.
- <kbd>Q</kbd> / <kbd>E</kbd>: Elevar o descender la cámara.
- <kbd>Flechas Izq / Der</kbd>: Rotar paneo de la cámara en 3D.
- <kbd>L</kbd>: Alternar fuentes de luz puntual (sirenas de los robots).
- <kbd>R</kbd>: Reiniciar posiciones de robots.
