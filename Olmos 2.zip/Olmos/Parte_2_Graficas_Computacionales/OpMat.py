import math

class OpMat3D:
    def __init__(self):
        self.mat = self._identity()
        self.stack = []

    def _identity(self):
        """Retorna la matriz identidad 4x4."""
        return [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ]

    def push(self):
        """Guarda una copia profunda del estado matricial actual en la pila."""
        self.stack.append([row[:] for row in self.mat])

    def pop(self):
        """Recupera la matriz anterior en la jerarquía."""
        if self.stack:
            self.mat = self.stack.pop()
        else:
            self.mat = self._identity()

    def reset(self):
        """Reinicia la matriz a la identidad y limpia la pila."""
        self.mat = self._identity()
        self.stack.clear()

    def _mult(self, A, B):
        """Multiplicación matricial 4x4."""
        res = [[0.0] * 4 for _ in range(4)]
        for i in range(4):
            for j in range(4):
                for k in range(4):
                    res[i][j] += A[i][k] * B[k][j]
        return res

    def translate(self, tx, ty, tz):
        T = [
            [1.0, 0.0, 0.0, tx],
            [0.0, 1.0, 0.0, ty],
            [0.0, 0.0, 1.0, tz],
            [0.0, 0.0, 0.0, 1.0]
        ]
        self.mat = self._mult(self.mat, T)

    def scale(self, sx, sy, sz):
        S = [
            [sx,  0.0, 0.0, 0.0],
            [0.0, sy,  0.0, 0.0],
            [0.0, 0.0, sz,  0.0],
            [0.0, 0.0, 0.0, 1.0]
        ]
        self.mat = self._mult(self.mat, S)

    def rotateX(self, deg):
        rad = math.radians(deg)
        c, s = math.cos(rad), math.sin(rad)
        R = [
            [1.0, 0.0, 0.0, 0.0],
            [0.0,   c,  -s, 0.0],
            [0.0,   s,   c, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ]
        self.mat = self._mult(self.mat, R)

    def rotateY(self, deg):
        rad = math.radians(deg)
        c, s = math.cos(rad), math.sin(rad)
        R = [
            [  c, 0.0,   s, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [ -s, 0.0,   c, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ]
        self.mat = self._mult(self.mat, R)

    def rotateZ(self, deg):
        rad = math.radians(deg)
        c, s = math.cos(rad), math.sin(rad)
        R = [
            [  c,  -s, 0.0, 0.0],
            [  s,   c, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ]
        self.mat = self._mult(self.mat, R)

    def rotateFree(self, deg, a, b, c):
        """
        Rotación libre alrededor de un eje arbitrario (a, b, c) desde el origen.
        Implementa la matriz colapsada de Rodrigues (equivalente a las 5 multiplicaciones).
        """
        norm = math.sqrt(a * a + b * b + c * c)
        if norm == 0.0:
            return  # Vector nulo

        # 1. Normalización del vector director
        ux, uy, uz = a / norm, b / norm, c / norm

        rad = math.radians(deg)
        cos_t = math.cos(rad)
        sin_t = math.sin(rad)
        omc = 1.0 - cos_t  # (1 - cos(theta))

        # 2. Matriz colapsada directa
        R = [
            [cos_t + (ux**2)*omc,         ux*uy*omc - uz*sin_t,     ux*uz*omc + uy*sin_t,     0.0],
            [uy*ux*omc + uz*sin_t,        cos_t + (uy**2)*omc,      uy*uz*omc - ux*sin_t,     0.0],
            [uz*ux*omc - uy*sin_t,        uz*uy*omc + ux*sin_t,     cos_t + (uz**2)*omc,      0.0],
            [0.0,                         0.0,                      0.0,                      1.0]
        ]
        self.mat = self._mult(self.mat, R)

    def get_matrix(self):
        """Retorna la matriz actual 4x4 en formato de lista de listas (row-major)."""
        return [row[:] for row in self.mat]

    def get_gl_matrix(self):
        """
        Retorna la matriz 4x4 en formato plano de 16 flotantes en orden Column-Major,
        exactamente como lo requiere OpenGL para glMultMatrixf / glLoadMatrixf.
        """
        gl_mat = []
        for col in range(4):
            for row in range(4):
                gl_mat.append(self.mat[row][col])
        return gl_mat

    def transform(self, points):
        """Multiplica M * P para cada punto en coordenadas homogéneas."""
        transformed = []
        for p in points:
            x = self.mat[0][0]*p[0] + self.mat[0][1]*p[1] + self.mat[0][2]*p[2] + self.mat[0][3]*p[3]
            y = self.mat[1][0]*p[0] + self.mat[1][1]*p[1] + self.mat[1][2]*p[2] + self.mat[1][3]*p[3]
            z = self.mat[2][0]*p[0] + self.mat[2][1]*p[1] + self.mat[2][2]*p[2] + self.mat[2][3]*p[3]
            w = self.mat[3][0]*p[0] + self.mat[3][1]*p[1] + self.mat[3][2]*p[2] + self.mat[3][3]*p[3]

            if w != 0.0 and w != 1.0:
                x /= w
                y /= w
                z /= w

            transformed.append([x, y, z, 1.0])
        return transformed
