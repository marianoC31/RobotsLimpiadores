#!/usr/bin/env python3
"""Lanzador de conveniencia para ejecutar la Parte 1 (Sistemas Multiagentes)."""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARTE_1_DIR = os.path.join(BASE_DIR, "Parte_1_Sistemas_Multiagentes")

if __name__ == "__main__":
    os.chdir(PARTE_1_DIR)
    sys.path.insert(0, PARTE_1_DIR)
    import main
    main.main()

