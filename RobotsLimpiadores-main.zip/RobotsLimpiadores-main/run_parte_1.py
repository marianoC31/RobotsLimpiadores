#!/usr/bin/env python3
"""Lanzador directo de la Parte 1 (Sistemas Multiagentes)."""
import os
import sys

RAIZ = os.path.dirname(os.path.abspath(__file__))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

from parte1_multiagentes.main import ejecutar_simulacion

if __name__ == "__main__":
    semilla = int(sys.argv[1]) if len(sys.argv) > 1 else 42
    ejecutar_simulacion(semilla=semilla)

