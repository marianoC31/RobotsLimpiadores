#!/usr/bin/env python3
"""Lanzador directo de la Parte 2 (Gráficas Computacionales 3D)."""
import os
import sys

RAIZ = os.path.dirname(os.path.abspath(__file__))
CARPETA = os.path.join(RAIZ, "parte2_graficas")
sys.path[:0] = [CARPETA, RAIZ]

import runpy
runpy.run_path(os.path.join(CARPETA, "main.py"), run_name="__main__")

